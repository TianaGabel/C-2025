#ifndef IMAGE_H
#define IMAGE_H

class Image {
    public:
        int ReadImage(char* file_name, char* checksum_name);
};

#endif